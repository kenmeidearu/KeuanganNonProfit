<div class="sidebar" data-active-color="rose" data-background-color="black" data-image="assets/img/sidebar-1.jpg">
			<div class="logo">
				<a href="<?php echo base_url();?>" class="simple-text">
		            FIKT
		        </a>
			
			</div>

			<div class="logo logo-mini">
				<a href="<?php echo base_url();?>" class="simple-text">
					Ct
				</a>
			
			</div>

			<div class="sidebar-wrapper">
				<div class="user">
					<div class="photo">
						<img src="assets/img/faces/avatar.jpg"/>
					</div>
					<div class="info">
						<a data-toggle="collapse" href="#user" class="collapsed">
		                    <?php echo $userLogin;?>
		                    <b class="caret"></b>
		                </a>
					
						<div class="collapse" id="user">
							<ul class="nav">
								<li><a href="profile.php">My Profile</a>
								</li>
								<li><a href="#">Settings</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<ul class="nav">
					<li class="active">
						<a href="dashboard.html">
		                    <i class="material-icons">dashboard</i>
		                    <p>Dashboard</p>
		                </a>
					
					</li>

					<li>
						<a data-toggle="collapse" href="#setup">
		                    <i class="material-icons">image</i>
		                    <p>SetUp
		                       <b class="caret"></b>
		                    </p>
		                </a>
					

						<div class="collapse" id="setup">
							<ul class="nav">
								<li>
									<a href="pages/pricing.html">COA</a>
								</li>
								<li>
									<a href="pages/timeline.html">Organisasi</a>
								</li>

							</ul>
						</div>
					</li>

					<li>
						<a data-toggle="collapse" href="#transaksi">
		                    <i class="material-icons">apps</i>
		                    <p>Transaksi
		                       <b class="caret"></b>
		                    </p>
		                </a>
					

						<div class="collapse" id="transaksi">
							<ul class="nav">
								<li>
									<a href="components/buttons.html">Jurnal Umum</a>
								</li>
								<li>
									<a href="components/grid.html">Jurnal Pengeluaran Kas</a>
								</li>
								<li>
									<a href="components/panels.html">Posting</a>
								</li>
							</ul>
						</div>
					</li>

					<li>
						<a data-toggle="collapse" href="#laporan">
		                    <i class="material-icons">content_paste</i>
		                    <p>Laporan
		                       <b class="caret"></b>
		                    </p>
		                </a>
					

						<div class="collapse" id="laporan">
							<ul class="nav">
								<li>
									<a href="forms/regular.html">Buku Jurnal</a>
								</li>
								<li>
									<a href="forms/extended.html">Neraca Percobaan</a>
								</li>
								<li>
									<a href="forms/validation.html">SHU</a>
								</li>
								<li>
									<a href="forms/wizard.html">Rugi Laba</a>
								</li>
								<li>
									<a href="forms/wizard.html">Neraca</a>
								</li>
							</ul>
						</div>
					</li>

					<li>
						<a href="calendar.html">
		                    <i class="material-icons">date_range</i>
		                    <p>Calendar</p>
		                </a>
					
					</li>
				</ul>
			</div>
		</div>