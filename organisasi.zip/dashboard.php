<?php
session_start();
//untuk waktu
//$tanggal = date( "d/m/Y" );

//untuk koneksi database
include "./include/conn.php";

$koneksi = open_connection();

if (!isset( $_SESSION[ 'id_admin' ] ) ) {
	echo '<script language="javascript">document.location.href="index.php?status=forbidden"</script>';
} else {
	$id_admin = $_SESSION[ 'id_admin' ];
	$userLogin=$_SESSION['nama'];
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png"/>
	<link rel="icon" type="image/png" href="assets/img/favicon.png"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>FIKT - Admin Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
	<meta name="viewport" content="width=device-width"/>

	

	<!-- Bootstrap core CSS     -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

	<!--  Material Dashboard CSS  -->
	<link href="assets/css/material-dashboard.css" rel="stylesheet"/>

	<!--  CSS for Demo Purpose, don't include it in your project  -->
	<link href="assets/css/demo.css" rel="stylesheet"/>

	<!--  Fonts and icons  -->
	<link href="../../../maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"/>
</head>

<body>
	<div class="wrapper">
		<?php include('include/sidebar.php');?>

		<div class="main-panel">
			<?php include('include/top.php');?>
			<div class="content">
				<div class="container-fluid">
					<div class="header text-center">
				        <h3 class="title">Selamat Datang di Dashoboard Keuangan FIKT</h3>
				        <p class="category">selalu transparan dan bersih dalam setiap langkah</p>
				    </div>

				    <div class="row">
				        <div class="col-md-4">
				            <div class="card card-chart">
				                <div class="card-header" data-background-color="rose">
				                    <div id="roundedLineChart" class="ct-chart"></div>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Rounded Line Chart</h4>
				                    <p class="category">Line Chart</p>
				                </div>
				            </div>
				        </div>

				        <div class="col-md-4">
				            <div class="card card-chart">
				                <div class="card-header" data-background-color="orange">
				                    <div id="straightLinesChart" class="ct-chart"></div>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Straight Lines Chart</h4>
				                    <p class="category">Line Chart with Points</p>
				                </div>
				            </div>
				        </div>

				        <div class="col-md-4">
				            <div class="card card-chart">
				                <div class="card-header" data-background-color="blue">
				                    <div id="simpleBarChart" class="ct-chart"></div>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Simple Bar Chart</h4>
				                    <p class="category">Bar Chart</p>
				                </div>
				            </div>
				        </div>
				    </div>

				    <div class="row">
				        <div class="col-md-6">
				            <div class="card">
				                <div class="card-header card-header-icon" data-background-color="blue">
				                    <i class="material-icons">timeline</i>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Coloured Line Chart <small> - Rounded</small></h4>
				                </div>
				                <div id="colouredRoundedLineChart" class="ct-chart"></div>
				            </div>
				        </div>

				        <div class="col-md-6">
				            <div class="card">
				                <div class="card-header card-header-icon" data-background-color="rose">
				                    <i class="material-icons">insert_chart</i>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Multiple Bars Chart <small>- Bar Chart</small></h4>
				                </div>
				                <div id="multipleBarsChart" class="ct-chart"></div>
				            </div>
				        </div>
				    </div>

				    <div class="row">
				        <div class="col-md-7">
				            <div class="card">
				                <div class="card-header card-header-icon" data-background-color="blue">
				                    <i class="material-icons">timeline</i>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Coloured Bars Chart <small> - Rounded</small></h4>
				                </div>
				                <div id="colouredBarsChart" class="ct-chart"></div>
				            </div>
				        </div>

				        <div class="col-md-5">
				            <div class="card">
				                <div class="card-header card-header-icon" data-background-color="red">
				                    <i class="material-icons">pie_chart</i>
				                </div>
				                <div class="card-content">
				                    <h4 class="card-title">Pie Chart</h4>
				                </div>
				                <div id="chartPreferences" class="ct-chart"></div>
				                <div class="card-footer">
				                    <h6>Legend</h6>
				                    <i class="fa fa-circle text-info"></i> Apple
				                    <i class="fa fa-circle text-warning"></i> Samsung
				                    <i class="fa fa-circle text-danger"></i> Windows Phone
				                </div>
				            </div>
				        </div>
				    </div>
				</div>
			</div>

			<?php include('include/footer.php');?>
		</div>
	</div>
</body>
<?php include('include/assets.php');?>
<script type="text/javascript">
	$( document ).ready( function () {
		// Javascript method's body can be found in assets/js/demos.js
		demo.initCharts();
	} );
</script>

</html>