<?php
session_start();
//untuk waktu
$tanggal = date( "d/m/Y" );

//untuk koneksi database
include "./include/conn.php";

$koneksi = open_connection();

if ( isset( $_SESSION[ 'id_admin' ] ) ) {
	$id_admin = $_SESSION[ 'id_admin' ];
?>
	<!doctype html>
	<html lang="en">

	<head>
		<meta charset="utf-8"/>
		<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png"/>
		<link rel="icon" type="image/png" href="../assets/img/favicon.png"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

		<title>FIKT- Admin Dashboard</title>

		<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
		<meta name="viewport" content="width=device-width"/>
		<!-- Bootstrap core CSS     -->
		<link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
		<!--  Material Dashboard CSS  -->
		<link href="assets/css/material-dashboard.css" rel="stylesheet"/>

		<!--  CSS for Demo Purpose, don't include it in your project  -->
		<link href="assets/css/demo.css" rel="stylesheet"/>

		<!--  Fonts and icons  -->
		<link href="../../../maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"/>
	</head>

	<body>
		<div class="wrapper">
			<div class="sidebar" data-active-color="rose" data-background-color="black" data-image="../assets/img/sidebar-1.jpg">
				<!--
	        Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
	        Tip 2: you can also add an image using data-image tag
	        Tip 3: you can change the color of the sidebar with data-background-color="white | black"
	    -->

				<div class="logo">
					<a href="http://www.creative-tim.com/" class="simple-text">
		            Creative Tim
		        </a>
				
				</div>

				<div class="logo logo-mini">
					<a href="http://www.creative-tim.com/" class="simple-text">
					Ct
				</a>
				
				</div>

				<div class="sidebar-wrapper">
					<div class="user">
						<div class="photo">
							<img src="../assets/img/faces/avatar.jpg"/>
						</div>
						<div class="info">
							<a data-toggle="collapse" href="#collapseExample" class="collapsed">
		                    Tania Andrew
		                    <b class="caret"></b>
		                </a>
						
							<div class="collapse" id="collapseExample">
								<ul class="nav">
									<li><a href="#">My Profile</a>
									</li>
									<li><a href="#">Edit Profile</a>
									</li>
									<li><a href="#">Settings</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav">
						<li class="active">
							<a href="dashboard.html">
		                    <i class="material-icons">dashboard</i>
		                    <p>Dashboard</p>
		                </a>
						
						</li>

						<li>
							<a data-toggle="collapse" href="#pagesExamples">
		                    <i class="material-icons">image</i>
		                    <p>Pages
		                       <b class="caret"></b>
		                    </p>
		                </a>
						

							<div class="collapse" id="pagesExamples">
								<ul class="nav">
									<li>
										<a href="pages/pricing.html">Pricing</a>
									</li>
									<li>
										<a href="pages/timeline.html">Timeline</a>
									</li>
									<li>
										<a href="pages/login.html">Login Page</a>
									</li>
									<li>
										<a href="pages/register.html">Register Page</a>
									</li>
									<li>
										<a href="pages/lock.html">Lock Screen Page</a>
									</li>
									<li>
										<a href="pages/user.html">User Profile</a>
									</li>
								</ul>
							</div>
						</li>

						<li>
							<a data-toggle="collapse" href="#componentsExamples">
		                    <i class="material-icons">apps</i>
		                    <p>Components
		                       <b class="caret"></b>
		                    </p>
		                </a>
						

							<div class="collapse" id="componentsExamples">
								<ul class="nav">
									<li>
										<a href="components/buttons.html">Buttons</a>
									</li>
									<li>
										<a href="components/grid.html">Grid System</a>
									</li>
									<li>
										<a href="components/panels.html">Panels</a>
									</li>
									<li>
										<a href="components/sweet-alert.html">Sweet Alert</a>
									</li>
									<li>
										<a href="components/notifications.html">Notifications</a>
									</li>
									<li>
										<a href="components/icons.html">Icons</a>
									</li>
									<li>
										<a href="components/typography.html">Typography</a>
									</li>
								</ul>
							</div>
						</li>

						<li>
							<a data-toggle="collapse" href="#formsExamples">
		                    <i class="material-icons">content_paste</i>
		                    <p>Forms
		                       <b class="caret"></b>
		                    </p>
		                </a>
						

							<div class="collapse" id="formsExamples">
								<ul class="nav">
									<li>
										<a href="forms/regular.html">Regular Forms</a>
									</li>
									<li>
										<a href="forms/extended.html">Extended Forms</a>
									</li>
									<li>
										<a href="forms/validation.html">Validation Forms</a>
									</li>
									<li>
										<a href="forms/wizard.html">Wizard</a>
									</li>
								</ul>
							</div>
						</li>

						<li>
							<a data-toggle="collapse" href="#tablesExamples">
		                    <i class="material-icons">grid_on</i>
		                    <p>Tables
		                       <b class="caret"></b>
		                    </p>
		                </a>
						

							<div class="collapse" id="tablesExamples">
								<ul class="nav">
									<li>
										<a href="tables/regular.html">Regular Tables</a>
									</li>
									<li>
										<a href="tables/extended.html">Extended Tables</a>
									</li>
									<li>
										<a href="tables/datatables.net.html">DataTables.net</a>
									</li>
								</ul>
							</div>
						</li>

						<li>
							<a data-toggle="collapse" href="#mapsExamples">
		                    <i class="material-icons">place</i>
		                    <p>Maps
		                       <b class="caret"></b>
		                    </p>
		                </a>
						

							<div class="collapse" id="mapsExamples">
								<ul class="nav">
									<li>
										<a href="maps/google.html">Google Maps</a>
									</li>
									<li>
										<a href="maps/fullscreen.html">Full Screen Map</a>
									</li>
									<li>
										<a href="maps/vector.html">Vector Map</a>
									</li>
								</ul>
							</div>
						</li>

						<li>
							<a href="widgets.html">
		                    <i class="material-icons">widgets</i>
		                    <p>Widgets</p>
		                </a>
						
						</li>

						<li>
							<a href="charts.html">
		                    <i class="material-icons">timeline</i>
		                    <p>Charts</p>
		                </a>
						
						</li>

						<li>
							<a href="calendar.html">
		                    <i class="material-icons">date_range</i>
		                    <p>Calendar</p>
		                </a>
						
						</li>
					</ul>
				</div>
			</div>


			<div class="main-panel">
				<nav class="navbar navbar-transparent navbar-absolute">
					<div class="container-fluid">
						<div class="navbar-minimize">
							<button id="minimizeSidebar" class="btn btn-round btn-white btn-fill btn-just-icon">
			                <i class="material-icons visible-on-sidebar-regular">more_vert</i>
			                <i class="material-icons visible-on-sidebar-mini">view_list</i>
			            </button>
						
						</div>
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse">
			                <span class="sr-only">Toggle navigation</span>
			                <span class="icon-bar"></span>
			                <span class="icon-bar"></span>
			                <span class="icon-bar"></span>
			            </button>
						
							<a class="navbar-brand" href="#"> Dashboard </a>
						</div>
						<div class="collapse navbar-collapse">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
			                        <i class="material-icons">dashboard</i>
			                        <p class="hidden-lg hidden-md">Dashboard</p>
			                    </a>
								
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown">
			                        <i class="material-icons">notifications</i>
			                        <span class="notification">5</span>
			                        <p class="hidden-lg hidden-md">
			                            Notifications
			                            <b class="caret"></b>
			                        </p>
			                    </a>
								
									<ul class="dropdown-menu">
										<li><a href="#">Mike John responded to your email</a>
										</li>
										<li><a href="#">You have 5 new tasks</a>
										</li>
										<li><a href="#">You're now friend with Andrew</a>
										</li>
										<li><a href="#">Another Notification</a>
										</li>
										<li><a href="#">Another One</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
			                       <i class="material-icons">person</i>
			                       <p class="hidden-lg hidden-md">Profile</p>
			                    </a>
								
								</li>

								<li class="separator hidden-lg hidden-md"></li>
							</ul>

							<form class="navbar-form navbar-right" role="search">
								<div class="form-group form-search is-empty">
									<input type="text" class="form-control" placeholder="Search">
									<span class="material-input"></span>
								</div>
								<button type="submit" class="btn btn-white btn-round btn-just-icon">
			                    <i class="material-icons">search</i><div class="ripple-container"></div>
			                </button>
							
							</form>
						</div>
					</div>
				</nav>

				<div class="content">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-12">
								<div class="card">
									<div class="card-header card-header-icon" data-background-color="green">
										<i class="material-icons">language</i>
									</div>
									<div class="card-content">
										<h4 class="card-title">Global Sales by Top Locations</h4>
										<div class="row">
											<div class="col-md-5">
												<div class="table-responsive table-sales">
													<table class="table">
														<tbody>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/US.png">
																	</div>
																</td>
																<td>USA</td>
																<td class="text-right">
																	2.920
																</td>
																<td class="text-right">
																	53.23%
																</td>
															</tr>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/DE.png">
																	</div>
																</td>
																<td>Germany</td>
																<td class="text-right">
																	1.300
																</td>
																<td class="text-right">
																	20.43%
																</td>
															</tr>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/AU.png">
																	</div>
																</td>
																<td>Australia</td>
																<td class="text-right">
																	760
																</td>
																<td class="text-right">
																	10.35%
																</td>
															</tr>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/GB.png">
																	</div>
																</td>
																<td>United Kingdom</td>
																<td class="text-right">
																	690
																</td>
																<td class="text-right">
																	7.87%
																</td>
															</tr>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/RO.png">
																	</div>
																</td>
																<td>Romania</td>
																<td class="text-right">
																	600
																</td>
																<td class="text-right">
																	5.94%
																</td>
															</tr>
															<tr>
																<td>
																	<div class="flag">
																		<img src="../assets/img/flags/BR.png">
																	</div>
																</td>
																<td>Brasil</td>
																<td class="text-right">
																	550
																</td>
																<td class="text-right">
																	4.34%
																</td>
															</tr>
														</tbody>
													</table>
												</div>
											</div>
											<div class="col-md-6 col-md-offset-1">
												<div id="worldMap" class="map"></div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-4">
								<div class="card card-chart">
									<div class="card-header" data-background-color="rose" data-header-animation="true">
										<div class="ct-chart" id="websiteViewsChart"></div>
									</div>
									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="Refresh">
											<i class="material-icons">refresh</i>
										</button>
										
											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="Change Date">
											<i class="material-icons">edit</i>
										</button>
										
										</div>

										<h4 class="card-title">Website Views</h4>
										<p class="category">Last Campaign Performance</p>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">access_time</i> campaign sent 2 days ago
										</div>
									</div>

								</div>
							</div>

							<div class="col-md-4">
								<div class="card card-chart">
									<div class="card-header" data-background-color="green" data-header-animation="true">
										<div class="ct-chart" id="dailySalesChart"></div>
									</div>
									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="Refresh">
											<i class="material-icons">refresh</i>
										</button>
										
											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="Change Date">
											<i class="material-icons">edit</i>
										</button>
										
										</div>

										<h4 class="card-title">Daily Sales</h4>
										<p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.</p>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">access_time</i> updated 4 minutes ago
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<div class="card card-chart">
									<div class="card-header" data-background-color="blue" data-header-animation="true">
										<div class="ct-chart" id="completedTasksChart"></div>
									</div>
									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-info btn-simple" rel="tooltip" data-placement="bottom" title="Refresh">
											<i class="material-icons">refresh</i>
										</button>
										
											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="Change Date">
											<i class="material-icons">edit</i>
										</button>
										
										</div>

										<h4 class="card-title">Completed Tasks</h4>
										<p class="category">Last Campaign Performance</p>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">access_time</i> campaign sent 2 days ago
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header" data-background-color="orange">
										<i class="material-icons">weekend</i>
									</div>
									<div class="card-content">
										<p class="category">Bookings</p>
										<h3 class="card-title">184</h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons text-danger">warning</i> <a href="#pablo">Get More Space...</a>
										</div>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header" data-background-color="rose">
										<i class="material-icons">equalizer</i>
									</div>
									<div class="card-content">
										<p class="category">Website Visits</p>
										<h3 class="card-title">75.521</h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">local_offer</i> Tracked from Google Analytics
										</div>
									</div>
								</div>
							</div>


							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header" data-background-color="green">
										<i class="material-icons">store</i>
									</div>
									<div class="card-content">
										<p class="category">Revenue</p>
										<h3 class="card-title">$34,245</h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">date_range</i> Last 24 Hours
										</div>
									</div>
								</div>
							</div>

							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="card card-stats">
									<div class="card-header" data-background-color="blue">
										<i class="fa fa-twitter"></i>
									</div>
									<div class="card-content">
										<p class="category">Followers</p>
										<h3 class="card-title">+245</h3>
									</div>
									<div class="card-footer">
										<div class="stats">
											<i class="material-icons">update</i> Just Updated
										</div>
									</div>
								</div>
							</div>
						</div>

						<h3>Manage Listings</h3>
						<br>
						<div class="row">
							<div class="col-md-4">
								<div class="card card-product">
									<div class="card-image" data-header-animation="true">
										<a href="#pablo">
										<img class="img" src="../assets/img/card-2.jpg">
									</a>
									
									</div>

									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="View">
											<i class="material-icons">art_track</i>
										</button>
										
											<button type="button" class="btn btn-success btn-simple" rel="tooltip" data-placement="bottom" title="Edit">
											<i class="material-icons">edit</i>
										</button>
										
											<button type="button" class="btn btn-danger btn-simple" rel="tooltip" data-placement="bottom" title="Remove">
											<i class="material-icons">close</i>
										</button>
										
										</div>

										<h4 class="card-title">
										<a href="#pablo">Cozy 5 Stars Apartment</a>
									</h4>
									
										<div class="card-description">
											The place is close to Barceloneta Beach and bus stop just 2 min by walk and near to "Naviglio" where you can enjoy the main night life in Barcelona.
										</div>
									</div>
									<div class="card-footer">
										<div class="price">
											<h4>$899/night</h4>
										</div>
										<div class="stats pull-right">
											<p class="category"><i class="material-icons">place</i> Barcelona, Spain</p>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<div class="card card-product">
									<div class="card-image" data-header-animation="true">
										<a href="#pablo">
										<img class="img" src="../assets/img/card-3.jpg">
									</a>
									
									</div>

									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="View">
											<i class="material-icons">art_track</i>
										</button>
										
											<button type="button" class="btn btn-success btn-simple" rel="tooltip" data-placement="bottom" title="Edit">
											<i class="material-icons">edit</i>
										</button>
										
											<button type="button" class="btn btn-danger btn-simple" rel="tooltip" data-placement="bottom" title="Remove">
											<i class="material-icons">close</i>
										</button>
										
										</div>

										<h4 class="card-title">
										<a href="#pablo">Office Studio</a>
									</h4>
									
										<div class="card-description">
											The place is close to Metro Station and bus stop just 2 min by walk and near to "Naviglio" where you can enjoy the night life in London, UK.
										</div>
									</div>
									<div class="card-footer">
										<div class="price">
											<h4>$1.119/night</h4>
										</div>
										<div class="stats pull-right">
											<p class="category"><i class="material-icons">place</i> London, UK</p>
										</div>
									</div>
								</div>
							</div>

							<div class="col-md-4">
								<div class="card card-product">
									<div class="card-image" data-header-animation="true">
										<a href="#pablo">
										<img class="img" src="../assets/img/card-1.jpg">
									</a>
									
									</div>

									<div class="card-content">
										<div class="card-actions">
											<button type="button" class="btn btn-danger btn-simple fix-broken-card">
											<i class="material-icons">build</i> Fix Header!
										</button>
										

											<button type="button" class="btn btn-default btn-simple" rel="tooltip" data-placement="bottom" title="View">
											<i class="material-icons">art_track</i>
										</button>
										
											<button type="button" class="btn btn-success btn-simple" rel="tooltip" data-placement="bottom" title="Edit">
											<i class="material-icons">edit</i>
										</button>
										
											<button type="button" class="btn btn-danger btn-simple" rel="tooltip" data-placement="bottom" title="Remove">
											<i class="material-icons">close</i>
										</button>
										
										</div>

										<h4 class="card-title">
										<a href="#pablo">Beautiful Castle</a>
									</h4>
									
										<div class="card-description">
											The place is close to Metro Station and bus stop just 2 min by walk and near to "Naviglio" where you can enjoy the main night life in Milan.
										</div>
									</div>
									<div class="card-footer">
										<div class="price">
											<h4>$459/night</h4>
										</div>
										<div class="stats pull-right">
											<p class="category"><i class="material-icons">place</i> Milan, Italy</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<footer class="footer">
					<div class="container-fluid">
						<nav class="pull-left">
							<ul>
								<li>
									<a href="#">
			                        Home
			                    </a>
								
								</li>
								<li>
									<a href="#">
			                        Company
			                    </a>
								
								</li>
								<li>
									<a href="#">
			                        Portfolio
			                    </a>
								
								</li>
								<li>
									<a href="#">
			                       Blog
			                    </a>
								
								</li>
							</ul>
						</nav>
						<p class="copyright pull-right">
							&copy;
							<script>
								document.write( new Date().getFullYear() )
							</script> <a href="http://www.creative-tim.com/">Creative Tim</a>, made with love for a better web
						</p>
					</div>
				</footer>
			</div>
		</div>
	</body>

	<!--   Core JS Files   -->
	<script src="../assets/js/jquery-3.1.1.min.js" type="text/javascript"></script>
	<script src="../assets/js/jquery-ui.min.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../assets/js/material.min.js" type="text/javascript"></script>
	<script src="../assets/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>

	<!-- Forms Validations Plugin -->
	<script src="../assets/js/jquery.validate.min.js"></script>

	<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
	<script src="../assets/js/moment.min.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

	<!--   Sharrre Library    -->
	<script src="../assets/js/jquery.sharrre.js"></script>

	<!--  Plugin for the Wizard -->
	<script src="../assets/js/jquery.bootstrap-wizard.js"></script>

	<!--  Notifications Plugin    -->
	<script src="../assets/js/bootstrap-notify.js"></script>

	<!-- DateTimePicker Plugin -->
	<script src="../assets/js/bootstrap-datetimepicker.js"></script>

	<!-- Vector Map plugin -->
	<script src="../assets/js/jquery-jvectormap.js"></script>

	<!-- Sliders Plugin -->
	<script src="../assets/js/nouislider.min.js"></script>

	<!--  Google Maps Plugin    -->
	<script src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Select Plugin -->
	<script src="../assets/js/jquery.dropdown.js"></script>

	<!--  DataTables.net Plugin    -->
	<script src="../assets/js/jquery.datatables.js"></script>

	<!-- Sweet Alert 2 plugin -->
	<script src="../assets/js/sweetalert2.js"></script>

	<!--  Full Calendar Plugin    -->
	<script src="../assets/js/fullcalendar.min.js"></script>

	<!-- TagsInput Plugin -->
	<script src="../assets/js/jquery.tagsinput.js"></script>

	<!-- Material Dashboard javascript methods -->
	<script src="../assets/js/material-dashboard.js"></script>

	<!-- Material Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script type="text/javascript">
		$( document ).ready( function () {

			// Javascript method's body can be found in assets/js/demos.js
			demo.initDashboardPageCharts();

			demo.initVectorMap();
		} );
	</script>

	</html>
	<?php
} else {
	echo '<script language="javascript">document.location.href="index.php?status=forbidden"</script>';
}
?>