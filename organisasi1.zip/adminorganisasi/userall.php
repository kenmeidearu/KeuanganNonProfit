<?php
session_start();
//untuk waktu
$tanggal = date( "d/m/Y" );

//untuk koneksi database
include "./include/conn.php";
include "./proses/getuser.php";

//$koneksi = open_connection();

/*if ( !isset( $_SESSION[ 'id_admin' ] ) ) {
	echo '<script language="javascript">document.location.href="index.php?status=forbidden"</script>';
} else {
*/
$allUser = GetAllUser();

//}
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8"/>
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png"/>
	<link rel="icon" type="image/png" href="assets/img/favicon.png"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>FIKT - All User</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
	<meta name="viewport" content="width=device-width"/>



	<!-- Bootstrap core CSS     -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

	<!--  Material Dashboard CSS  -->
	<link href="assets/css/material-dashboard.css" rel="stylesheet"/>

	<!--  CSS for Demo Purpose, don't include it in your project  -->
	<link href="assets/css/demo.css" rel="stylesheet"/>

	<!--  Fonts and icons  -->
	<link href="../../../maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"/>
</head>

<body>
	<div class="wrapper">
		<?php include('include/sidebar.php');?>

		<div class="main-panel">
			<?php include('include/top.php');?>
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="purple">
									<i class="material-icons">assignment</i>
								</div>
								<div class="card-content">
									<h4 class="card-title">All User</h4>
									<div class="toolbar">
										<!-- Button to trigger modal -->
										<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#modalForm">
										Add User
										</button>
									
									</div>
									<div class="material-datatables">
										<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
											<thead>
												<tr>
													<th>Name</th>
													<th>User Login</th>
													<th>Password</th>
													<th>Status</th>
													<th>Tanggal</th>
													<th class="disabled-sorting text-right">Actions</th>
												</tr>
											</thead>
											<tfoot>
												<tr>
													<th>Name</th>
													<th>User Login</th>
													<th>Password</th>
													<th>Status</th>
													<th>Tanggal</th>
													<th class="text-right">Actions</th>
												</tr>
											</tfoot>
											<tbody>
												<?php 
												//begin data
												//print_r($allUser);
												foreach($allUser as $theData){
												?>
												<tr>
													<td id="someid">
														<?php echo $theData->name;?>
													</td>
													<td>
														<?php echo $theData->username;?>
													</td>
													<td>
														<?php echo $theData->password;?>
													</td>
													<td align="center">
														<?php if($theData->status==1){
														echo '<span class="material-icons">checked</span>';
												    }else{
														echo '<span class="material-icons">close</span>';
												    }?>

													</td>
													<td>
														<?php echo $theData->tgl;?>
													</td>
													<td class="text-right">
														<a href="#modalForm" id="<?php echo  $theData->uid; ?>" data-toggle="modal" data-target="#modalForm" class="btn btn-simple btn-info btn-icon edit"><i class="material-icons" >edit</i></a>
														<a href="#" class="btn btn-simple btn-danger btn-icon remove"><i class="material-icons">close</i></a>
													</td>
												</tr>
												<?php
												}
												//end data
												?>

											</tbody>
										</table>
									</div>
								</div>
								<!-- end content-->
							</div>
							<!--  end card  -->
						</div>
						<!-- end col-md-12 -->
					</div>
					<!-- end row -->
				</div>
			</div>
			<?php include('include/footer.php');?>
			<?php include('include/addUser.php');?>
		</div>
	</div>
</body>
<?php include('include/assets.php');?>
<script src="assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">
	$( document ).ready( function () {
		setFormValidation( '#AddUserValidation' );
		$( '#datatables' ).DataTable( {
			"pagingType": "full_numbers",
			"lengthMenu": [
				[ 10, 25, 50, -1 ],
				[ 10, 25, 50, "All" ]
			],
			responsive: true,
			language: {
				search: "_INPUT_",
				searchPlaceholder: "Search records",
			}

		} );


		var table = $( '#datatables' ).DataTable();

		// Edit record
		table.on( 'click', '.edit', function () {
			$tr = $( this ).closest( 'tr' );
			var data = table.row( $tr ).data();
			//submitContactForm();
			//alert( 'You press on Row: ' + data[ 0 ] + ' ' + data[ 1 ] + ' ' + data[ 2 ] + '\'s row.' );
			//data[0]="Ipang Pinter";
			//table.row($tr).parent().replaceWith(data);
			//$('#modalForm').show();
			//$("#modalForm").data('num_id', data[ 0 ]).dialog('close').dialog('open');
		} );

		// Delete a record
		table.on( 'click', '.remove', function ( e ) {
			$tr = $( this ).closest( 'tr' );
			table.row( $tr ).remove().draw();
			e.preventDefault();
		} );

		$( '.card .material-datatables label' ).addClass( 'form-group' );
		
		
		
	} );

	/*$( '#modalForm' ).on( 'show.bs.modal', function ( event ) {
		var modal = $( this ),
			esseyId = event.relatedTarget.id;
		var table = $( '#datatables' ).DataTable();
		var tr = $(this).closest('tr');
		//var id = tr.children("td:eq(0)").attr('data-id')
		var data = table.row( tr ).data();
		modal.find( '.modal-title' ).text( 'Edit User' );
		modal.find( '.modal-body #inputName' ).val( esseyId );
		modal.find( '.modal-body #inputUser' ).val( data[ 0 ] );

		} );*/

	function setFormValidation( id ) {
		$( id ).validate( {
			errorPlacement: function ( error, element ) {
				$( element ).parent( 'div' ).addClass( 'has-error' );
			}
		} );
	}


	function submitContactForm() {
		var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		var name = $( '#inputName' ).val();
		var email = $( '#inputEmail' ).val();
		var message = $( '#inputMessage' ).val();
		if ( name.trim() == '' ) {
			alert( 'Please enter your name.' );
			$( '#inputName' ).focus();
			return false;
		} else if ( email.trim() == '' ) {
			alert( 'Please enter your email.' );
			$( '#inputEmail' ).focus();
			return false;
		} else if ( email.trim() != '' && !reg.test( email ) ) {
			alert( 'Please enter valid email.' );
			$( '#inputEmail' ).focus();
			return false;
		} else if ( message.trim() == '' ) {
			alert( 'Please enter your message.' );
			$( '#inputMessage' ).focus();
			return false;
		} else {
			$.ajax( {
				type: 'POST',
				url: 'submit_form.php',
				data: 'contactFrmSubmit=1&name=' + name + '&email=' + email + '&message=' + message,
				beforeSend: function () {
					$( '.submitBtn' ).attr( "disabled", "disabled" );
					$( '.modal-body' ).css( 'opacity', '.5' );
				},
				success: function ( msg ) {
					if ( msg == 'ok' ) {
						$( '#inputName' ).val( '' );
						$( '#inputEmail' ).val( '' );
						$( '#inputMessage' ).val( '' );
						$( '.statusMsg' ).html( '<span style="color:green;">Thanks for contacting us, we\'ll get back to you soon.</p>' );
					} else {
						$( '.statusMsg' ).html( '<span style="color:red;">Some problem occurred, please try again.</span>' );
					}
					$( '.submitBtn' ).removeAttr( "disabled" );
					$( '.modal-body' ).css( 'opacity', '' );
				}
			} );
		}
	}
</script>

</html>