<?php
session_start();
//untuk waktu
$tanggal = date( "d/m/Y" );

//untuk koneksi database
include "./include/conn.php";
include "./proses/getuser.php";

$allUser = GetAllUser();

?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8"/>
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png"/>
	<link rel="icon" type="image/png" href="assets/img/favicon.png"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>FIKT - All User</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
	<meta name="viewport" content="width=device-width"/>



	<!-- Bootstrap core CSS     -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

	<!--  Material Dashboard CSS  -->
	<link href="assets/css/material-dashboard.css" rel="stylesheet"/>

	<!--  CSS for Demo Purpose, don't include it in your project  -->
	<link href="assets/css/demo.css" rel="stylesheet"/>

	<!--  Fonts and icons  -->
	<link href="../../../maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"/>
</head>

<body>
	<div class="wrapper">
		<?php include('include/sidebar.php');?>

		<div class="main-panel">
			<?php include('include/top.php');?>
			<div class="content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header card-header-icon" data-background-color="purple">
									<i class="material-icons">assignment</i>
								</div>
								<div class="card-content">
									<h4 class="card-title">All User</h4>
									<div class="toolbar">
										<!-- Button to trigger modal -->
										<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#modalForm">
										Add User
										</button>
									

									</div>
									<div class="material-datatables">
										<table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
											<thead>
												<tr>
													<th class="hidden">user</th>
													<th>Name</th>
													<th>User Login</th>
													<th>Email</th>
													<th>Status</th>
													<th>Tanggal</th>
													<th class="disabled-sorting text-right">Actions</th>
												</tr>
											</thead>
											<tfoot>
												<tr>
													<th class="hidden">user</th>
													<th>Name</th>
													<th>User Login</th>
													<th>Password</th>
													<th class="text-center">Status</th>
													<th>Tanggal</th>
													<th class="text-right">Actions</th>
												</tr>
											</tfoot>
											<tbody>
												<?php 
												//begin data
												//print_r($allUser);
												foreach($allUser as $theData){
												?>
												<tr>
													<td class="hidden">
														<?php echo $theData->uid;?>
													</td>
													<td>
														<?php echo $theData->name;?>
													</td>
													<td>
														<?php echo $theData->username;?>
													</td>
													<td>
														<?php echo $theData->email;?>
													</td>
													<td align="center" >
													<?php if($theData->status==1){
														echo '<span class="material-icons">done</span>';
												    }else{
														echo '<span class="material-icons">close</span>';
												    }?>

													</td>
													<td>
														<?php echo $theData->tgl;?>
													</td>
													<td class="text-right">
														<a href="#modalForm" id="<?php echo  $theData->uid; ?>" data-toggle="modal" data-target="#modalForm" class="btn btn-simple btn-info btn-icon edit"><i class="material-icons" >edit</i></a>
														<a href="#" class="btn btn-simple btn-danger btn-icon remove"><i class="material-icons">close</i></a>
													</td>
												</tr>
												<?php
												}
												//end data
												?>

											</tbody>
										</table>
									</div>
								</div>
								<!-- end content-->
							</div>
							<!--  end card  -->
						</div>
						<!-- end col-md-12 -->
					</div>
					<!-- end row -->
				</div>
			</div>
			<?php include('include/footer.php');?>
			<?php include('include/addUser.php');?>
		</div>
	</div>
</body>
<?php include('include/assets.php');?>
<script src="assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">
	$( document ).ready( function () {
		setFormValidation( '#AddUserValidation' );
		$( '#datatables' ).DataTable( {
			"pagingType": "full_numbers",
			"lengthMenu": [
				[ 10, 25, 50, -1 ],
				[ 10, 25, 50, "All" ]
			],
			responsive: true,
			language: {
				search: "_INPUT_",
				searchPlaceholder: "Search records",
			}

		} );


		var table = $( '#datatables' ).DataTable(),
			$modal = $( '#modalForm' );

		// Edit record
		table.on( 'click', '.edit', function () {
			$tr = $( this ).closest( 'tr' );
			var data = table.row( $tr ).data();
			$modal.data( 'dt', data );
		} );

		// Delete a record
		table.on( 'click', '.remove', function ( e ) {
			$tr = $( this ).closest( 'tr' );
			table.row( $tr ).remove().draw();
			e.preventDefault();
		} );

		$( '.card .material-datatables label' ).addClass( 'form-group' );

		$modal.on( 'show.bs.modal', function ( event ) {
			var row = $( this ).data( 'dt' );
			if(row!=null){
				$modal.find( '.modal-title' ).text( 'Edit User' );
				$modal.find( '.modal-body #users' ).val( row[ 0 ] );
				$modal.find( '.modal-body #inputName' ).val( row[ 1 ] );
				$modal.find( '.modal-body #inputUser' ).val( row[ 2 ] );
				$modal.find( '.modal-body #inputUser' ).readOnly=true;
				$modal.find( '.modal-body #inputEmail' ).val( row[ 3 ] );
				$modal.find( '.modal-body #groupPassword' ).hide();
				$modal.find( '.modal-body #groupRePassword' ).hide();
				if(row[ 4 ]=='<span class="material-icons">done</span>'){
					$modal.find( '.modal-body #active' ).prop( "checked"  , true );
				}else{
					$modal.find( '.modal-body #nonactive' ).prop("checked" , true );
				}
				$modal.data('dt',null);
			}else{
				$modal.find( '.modal-body #users' ).val(0);
				$modal.find( '.modal-body #inputName' ).val(null);
				$modal.find( '.modal-body #inputUser' ).val(null);
				$modal.find( '.modal-body #inputEmail' ).val(null);
				$modal.find( '.modal-body #active').prop( "checked",true);
				$modal.find( '.modal-body #inputUser' ).readOnly=false;
				$modal.find( '.modal-body #groupPassword' ).show();
				$modal.find( '.modal-body #groupRePassword' ).show();
			}
		} );
		
	} );

	function setFormValidation( id ) {
		$( id ).validate( {
			errorPlacement: function ( error, element ) {
				$( element ).parent( 'div' ).addClass( 'has-error' );
			}
		} );
	}
	
	


	function submitContactForm() {
		var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
		var uid = $( '#users' ).val();
		var name = $( '#inputName' ).val();
		var user = $( '#inputUser' ).val();
		var email = $( '#inputEmail' ).val();
		var pass = $( '#inputPassword' ).val();
		var repass = $( '#inputRePassword' ).val();
		var active = $( '#active' ).val();
		if ( name.trim() == '' ) {
			alert( 'Please enter your name.' );
			$( '#inputName' ).focus();
			return false;
		} else if ( user.trim() == '' ) {
			alert( 'Please enter your username.' );
			$( '#inputUser' ).focus();
			return false;
		}else if ( email.trim() == '' ) {
			alert( 'Please enter your Email.' );
			$( '#inputEmail' ).focus();
			return false;
		}else if ( pass.trim() == '' &&
				  (uid.trim()==null || uid.trim()=='0') ) {
			alert( 'Please enter your Email.' );
			$( '#inputPassword' ).focus();
			return false;
		}else if ( pass.trim() != '' ) {
			if(repass.trim()==''){
				alert( 'Please enter your RePassword.' );
				$( '#inputRePassword' ).focus();
				return false;
			}else{
				if(pass.trim!=repass.trim()){
					alert( 'RePassword different with password' );
					$( '#inputRePassword' ).focus();
					return false;
				}
			}
		} else if ( email.trim() != '' && !reg.test( email ) ) {
			alert( 'Please enter valid email.' );
			$( '#inputEmail' ).focus();
			return false;
		} else {
			$.ajax( {
				type: 'POST',
				url: 'proses/submit_user.php',
				data: 'uid='+ uid+'&user='+ user+'&name=' + name + '&email=' + email +'&pass=' + pass +'&active=' + active,
				beforeSend: function () {
					$( '.submitBtn' ).attr( "disabled", "disabled" );
					$( '.modal-body' ).css( 'opacity', '.5' );
				},
				success: function ( msg ) {
					$( '.submitBtn' ).removeAttr( "disabled" );
					$( '.modal-body' ).css( 'opacity', '' );
					if ( msg != 'ok' ) {
						$( '.statusMsg' ).html( '<span style="color:red;">Some problem occurred, please try again.'+msg+'</span>' );
					} else {
						 $('#modalForm').modal('toggle'); 
    					 return false;
					}
					
				}
			} );
		}
	}
</script>

</html>