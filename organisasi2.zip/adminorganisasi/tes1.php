<!DOCTYPE html>
<html> <head> 
<meta charset="UTF-8"> 
<title>Belajar Form HTML</title> </head> 
<body>
<form action="prosesform.php" method="post"> 
<div>
	Nama
</div> 
<div>
	<input type="text" name="nama_user">
</div>
<div>
	Alamat 
</div>
<div>
	<input type="text" name="alamat_user">
</div>
</form> 
</body> </html> 