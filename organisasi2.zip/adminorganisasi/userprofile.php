<?php
session_start();
//untuk waktu
$tanggal = date( "d/m/Y" );

//untuk koneksi database
include "./include/conn.php";
include "./proses/getuser.php";

//$koneksi = open_connection();

if ( !isset( $_SESSION[ 'id_admin' ] ) ) {
	echo '<script language="javascript">document.location.href="index.php?status=forbidden"</script>';
} else {
	$iduser = $_SESSION[ 'id_admin' ];
	$userLogin = $_SESSION[ 'user' ];
	$newuser = GetUserInfo($iduser,$userLogin);
	$nama=$newuser->name;
	$userLogin=$newuser->username;
	$iduser=$newuser->uid;
}
?>
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8"/>
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png"/>
	<link rel="icon" type="image/png" href="assets/img/favicon.png"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

	<title>FIKT - Admin Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
	<meta name="viewport" content="width=device-width"/>



	<!-- Bootstrap core CSS     -->
	<link href="assets/css/bootstrap.min.css" rel="stylesheet"/>

	<!--  Material Dashboard CSS  -->
	<link href="assets/css/material-dashboard.css" rel="stylesheet"/>

	<!--  CSS for Demo Purpose, don't include it in your project  -->
	<link href="assets/css/demo.css" rel="stylesheet"/>

	<!--  Fonts and icons  -->
	<link href="../../../maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"/>
</head>

<body>
	<div class="wrapper">
		<?php include('include/sidebar.php');?>

		<div class="main-panel">
			<?php include('include/top.php');?>
			<div class="content">
				<div class="container-fluid">
					<div class="header text-center">
						<h3 class="title">Setup For Your User Login</h3>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<form id="RegisterValidation" action="proses/userprofile.php" method="post">
									<div class="card-header card-header-icon" data-background-color="rose">
										<i class="material-icons">person</i>
									</div>
									<div class="card-content">
										<h4 class="card-title">Nama</h4>
										<div class="form-group label-floating">
											<label class="control-label">
				                                Nama
				                                <small>*</small>
				                            </label>
											<input class="form-control" name="nama" type="text" required="true" value="<?php echo $nama;?>"/>
										</div>
										<div class="form-group label-floating">
											<label class="control-label">
				                                User Login
				                                <small>*</small>
				                            </label>
										

											<input class="form-control" name="userlogin" type="text" required="true" readonly value="<?php echo $userLogin;?>" />
										</div>

										<div class="form-group label-floating">
											<label class="control-label">
				                                Password
				                                <small>*</small>
				                            </label>
										

											<input class="form-control" name="password" id="registerPassword" type="password" required="true"/>
										</div>

										<div class="form-group label-floating">
											<label class="control-label">
				                                Confirm Password
				                                <small>*</small>
				                            </label>
										

											<input class="form-control" name="password_confirmation" id="registerPasswordConfirmation" type="password" required="true" equalTo="#registerPassword"/>
										</div>
										<div class="category form-category"><small>*</small>Required fields</div>
										<div class="form-footer text-right">
											<div class="checkbox pull-left">
												<label>
				                                    <input type="checkbox" name="optionsCheckboxes">
				                                    check this for update password
				                                </label>
											</div>
											<input type="hidden" name="id" value="<?php echo $iduser;?>"/>
											<button type="submit" class="btn btn-rose btn-fill">Update</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include('include/footer.php');?>
		</div>
	</div>
</body>
<?php include('include/assets.php');?>
<script src="assets/js/jquery.validate.min.js"></script>
<script type="text/javascript">
	function setFormValidation( id ) {
		$(id).validate( {
			errorPlacement: function ( error, element ) {
				$( element ).parent( 'div' ).addClass( 'has-error' );
			}
		} );
	}

	$( document ).ready( function () {
		setFormValidation( '#RegisterValidation' );
		//setFormValidation('#TypeValidation');
		//setFormValidation('#LoginValidation');
		//setFormValidation('#RangeValidation');
	} );
</script>

</html>